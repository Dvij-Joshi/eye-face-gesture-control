import cv2
import mediapipe as mp
import pyautogui
import numpy as np
import time

# ─────────────────────────────────────────────
#  SETTINGS — tweak these to your comfort
# ─────────────────────────────────────────────
CAMERA_INDEX        = 0       # 0 = built-in webcam, 1 = external
SMOOTHING           = 7       # higher = smoother but slower mouse
HEAD_SENSITIVITY    = 8       # how fast head moves the cursor
MOUTH_THRESHOLD     = 0.06    # how wide mouth must open to click
WINK_THRESHOLD      = 0.015   # how closed eye must be to detect wink
BROW_THRESHOLD      = 0.27    # eyebrow raise height to trigger action
CLICK_COOLDOWN      = 1.0     # seconds between clicks to avoid spam
SHOW_ALL_LANDMARKS  = True    # set False to only show key points
# ─────────────────────────────────────────────

# MediaPipe setup
mp_face_mesh = mp.solutions.face_mesh
mp_drawing   = mp.solutions.drawing_utils
mp_styles    = mp.solutions.drawing_styles

# Key landmark indices (from MediaPipe 468-point face mesh)
NOSE_TIP        = 4
LEFT_EYE_TOP    = 159
LEFT_EYE_BOT    = 145
RIGHT_EYE_TOP   = 386
RIGHT_EYE_BOT   = 374
MOUTH_TOP       = 13
MOUTH_BOT       = 14
LEFT_BROW       = 105
RIGHT_BROW      = 334
FOREHEAD        = 10

# Screen size for mouse mapping
SCREEN_W, SCREEN_H = pyautogui.size()
pyautogui.FAILSAFE = False  # disable corner failsafe

# Smooth mouse movement using a buffer
mouse_buffer_x = []
mouse_buffer_y = []

last_click_time   = 0
last_rclick_time  = 0
last_action_time  = 0

def smooth_value(buffer, new_val, size):
    buffer.append(new_val)
    if len(buffer) > size:
        buffer.pop(0)
    return int(np.mean(buffer))

def get_landmark(landmarks, index, w, h):
    lm = landmarks[index]
    return int(lm.x * w), int(lm.y * h)

def eye_aspect_ratio(landmarks, top_idx, bot_idx):
    top = landmarks[top_idx]
    bot = landmarks[bot_idx]
    return abs(top.y - bot.y)

def mouth_open_ratio(landmarks):
    top = landmarks[MOUTH_TOP]
    bot = landmarks[MOUTH_BOT]
    return abs(top.y - bot.y)

def brow_height(landmarks, brow_idx, eye_idx):
    brow = landmarks[brow_idx]
    eye  = landmarks[eye_idx]
    return abs(brow.y - eye.y)


def main():
    global last_click_time, last_rclick_time, last_action_time
    global mouse_buffer_x, mouse_buffer_y

    cap = cv2.VideoCapture(CAMERA_INDEX)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    # Reference nose position (calibrated on first frames)
    ref_x, ref_y  = None, None
    calib_frames  = []
    CALIB_COUNT   = 20

    print("=" * 45)
    print("  PCV — Face Control  |  Press Q to quit")
    print("=" * 45)
    print("  Hold still for calibration (20 frames)...")

    with mp_face_mesh.FaceMesh(
        max_num_faces=1,
        refine_landmarks=True,
        min_detection_confidence=0.7,
        min_tracking_confidence=0.7
    ) as face_mesh:

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            frame = cv2.flip(frame, 1)  # mirror
            h, w  = frame.shape[:2]
            rgb   = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = face_mesh.process(rgb)

            status_lines = []

            if results.multi_face_landmarks:
                landmarks = results.multi_face_landmarks[0].landmark

                # ── Draw face mesh ──────────────────────────
                if SHOW_ALL_LANDMARKS:
                    mp_drawing.draw_landmarks(
                        image=frame,
                        landmark_list=results.multi_face_landmarks[0],
                        connections=mp_face_mesh.FACEMESH_TESSELATION,
                        landmark_drawing_spec=None,
                        connection_drawing_spec=mp_styles.get_default_face_mesh_tesselation_style()
                    )
                mp_drawing.draw_landmarks(
                    image=frame,
                    landmark_list=results.multi_face_landmarks[0],
                    connections=mp_face_mesh.FACEMESH_CONTOURS,
                    landmark_drawing_spec=None,
                    connection_drawing_spec=mp_styles.get_default_face_mesh_contours_style()
                )

                # ── Get nose position ───────────────────────
                nose_x, nose_y = get_landmark(landmarks, NOSE_TIP, w, h)

                # ── Calibration ─────────────────────────────
                if ref_x is None:
                    calib_frames.append((nose_x, nose_y))
                    cv2.putText(frame, f"Calibrating... {len(calib_frames)}/{CALIB_COUNT}",
                                (20, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
                    if len(calib_frames) >= CALIB_COUNT:
                        ref_x = int(np.mean([p[0] for p in calib_frames]))
                        ref_y = int(np.mean([p[1] for p in calib_frames]))
                        print(f"  Calibrated! Reference point: ({ref_x}, {ref_y})")
                        print("  Controls:")
                        print("    Head movement  → Mouse cursor")
                        print("    Open mouth     → Left click")
                        print("    Wink right eye → Right click")
                        print("    Raise eyebrows → Middle click / custom action")
                    continue

                # ── Mouse movement from head ─────────────────
                delta_x = (nose_x - ref_x) * HEAD_SENSITIVITY
                delta_y = (nose_y - ref_y) * HEAD_SENSITIVITY

                target_x = np.clip(SCREEN_W // 2 + delta_x, 0, SCREEN_W)
                target_y = np.clip(SCREEN_H // 2 + delta_y, 0, SCREEN_H)

                smooth_x = smooth_value(mouse_buffer_x, target_x, SMOOTHING)
                smooth_y = smooth_value(mouse_buffer_y, target_y, SMOOTHING)
                pyautogui.moveTo(smooth_x, smooth_y)

                # ── Mouth open → Left click ──────────────────
                mouth_ratio = mouth_open_ratio(landmarks)
                if mouth_ratio > MOUTH_THRESHOLD:
                    now = time.time()
                    if now - last_click_time > CLICK_COOLDOWN:
                        pyautogui.click()
                        last_click_time = now
                        status_lines.append(("LEFT CLICK", (0, 255, 0)))
                        print("  [ACTION] Left Click")

                # ── Right eye wink → Right click ─────────────
                right_ear = eye_aspect_ratio(landmarks, RIGHT_EYE_TOP, RIGHT_EYE_BOT)
                left_ear  = eye_aspect_ratio(landmarks, LEFT_EYE_TOP,  LEFT_EYE_BOT)

                if right_ear < WINK_THRESHOLD and left_ear > WINK_THRESHOLD * 2:
                    now = time.time()
                    if now - last_rclick_time > CLICK_COOLDOWN:
                        pyautogui.rightClick()
                        last_rclick_time = now
                        status_lines.append(("RIGHT CLICK", (0, 100, 255)))
                        print("  [ACTION] Right Click")

                # ── Eyebrow raise → Custom action ────────────
                left_brow_h  = brow_height(landmarks, LEFT_BROW,  LEFT_EYE_TOP)
                right_brow_h = brow_height(landmarks, RIGHT_BROW, RIGHT_EYE_TOP)
                avg_brow     = (left_brow_h + right_brow_h) / 2

                if avg_brow > BROW_THRESHOLD:
                    now = time.time()
                    if now - last_action_time > CLICK_COOLDOWN:
                        pyautogui.scroll(3)  # scroll up — change to anything you want
                        last_action_time = now
                        status_lines.append(("SCROLL UP", (255, 200, 0)))
                        print("  [ACTION] Scroll Up")

                # ── Draw key landmark dots ───────────────────
                for idx in [NOSE_TIP, MOUTH_TOP, MOUTH_BOT,
                             LEFT_EYE_TOP, LEFT_EYE_BOT,
                             RIGHT_EYE_TOP, RIGHT_EYE_BOT]:
                    px, py = get_landmark(landmarks, idx, w, h)
                    cv2.circle(frame, (px, py), 4, (0, 255, 255), -1)

                # ── HUD: show ratios for tuning ───────────────
                cv2.putText(frame, f"Mouth: {mouth_ratio:.4f}  (thresh {MOUTH_THRESHOLD})",
                            (10, h - 80), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)
                cv2.putText(frame, f"R.Eye: {right_ear:.4f}  L.Eye: {left_ear:.4f}",
                            (10, h - 55), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)
                cv2.putText(frame, f"Brow:  {avg_brow:.4f}  (thresh {BROW_THRESHOLD})",
                            (10, h - 30), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)

                # ── Action popup on screen ────────────────────
                for i, (text, color) in enumerate(status_lines):
                    cv2.putText(frame, text, (w // 2 - 80, 60 + i * 40),
                                cv2.FONT_HERSHEY_SIMPLEX, 1.2, color, 3)

            else:
                cv2.putText(frame, "No face detected", (20, 50),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

            # ── Title bar ────────────────────────────────────
            cv2.putText(frame, "PCV - Face Control  [Q = quit]",
                        (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)

            cv2.imshow("PCV - Face Control", frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    cap.release()
    cv2.destroyAllWindows()
    print("  PCV closed.")


if __name__ == "__main__":
    main()
